<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// $routes->get('/', 'Home::index');
$routes->get('/', 'loginController::index');
$routes->get('register', 'loginController::register');
$routes->post('loginController/check_user', 'loginController::check_user');
$routes->post('login/check_login', 'loginController::check_login');
$routes->get('dashboard', 'loginController::dashboard');
$routes->get('buyer', 'loginController::buyer');
$routes->get('seller', 'loginController::seller');
$routes->post('saveplace', 'loginController::saveplace');
$routes->post('getSeller', 'loginController::getSeller');
$routes->get('loginController/editSeller/(:num)', 'loginController::editSeller/$1');
$routes->post('loginController/saveEdit/(:num)', 'loginController::saveEdit/$1');
