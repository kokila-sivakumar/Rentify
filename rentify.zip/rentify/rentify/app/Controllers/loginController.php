<?php

namespace App\Controllers;

class loginController extends BaseController
{
    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->register = $this->db->table("register");
        $this->seller = $this->db->table("seller");
    }
    public function index()
    {
        return view('login/login');
    }
    public function register()
    {
        return view('login/register');
    }
    public function check_user()
    {
        $input = $this->request->getVar();
        unset($input['password']);
        $exist = $this->register->getWhere(['email' => $input['email']])->getResult();
        if (count($exist) == 0) {
            $result = $this->register->insert($input);
            $result = 100;
        } else {
            $result = 400;
        }
        echo json_encode($result);
    }
    public function check_login()
    {
        $input = $this->request->getVar();
        $exist = $this->register->getWhere(['email' => $input['email'], 'password' => $input['password']])->getResult();
        if (count($exist) == 1) {
            $result = 100;
        } else {
            $result = 200;
        }
        echo json_encode($result);
    }


    public function dashboard()
    {
        return view('login/dashboard');
    }
    public function buyer()
    {
        return view('login/buyer');
    }
    public function seller()
    {
        return view('login/seller');
    }
    public function saveplace()
    {
        $input = $this->request->getVar();
        $result = $this->seller->insert($input);
        echo json_encode($result);
    }
    public function getSeller()
    {
        $input = $this->request->getVar();
        $data = $this->seller->getWhere()->getResult();
        $table = '';
        $i = 1;
        foreach($data as $row)
        {
            $table.='
                <tr>
                    <td>'.$i.'</td>
                    <td>'.$row->name.'</td>
                    <td>'.$row->mobile_number.'</td>
                    <td>'.$row->place.'</td>
                    <td>'.$row->bed.'</td>
                    <td>'.$row->hospital.'</td>
                    <td>
                        <button class="btn btn-info" type="button" onclick="showMdModal(`'.base_url().'/loginController/editSeller/'.$row->id.'`,`Edit`)"><i class="fa fa-pen"></i></button>
                        <button class="btn btn-danger" type="button" onclick="deleteUser('.$row->id.')"><i class="fa fa-trash"></i></button>
                    </td>
                </tr>
            ';
            $i++;
        }
        echo json_encode($table);
    }
    public function editSeller($id)
    {
        $data['edit'] = $this->seller->getWhere(['id'=>$id])->getRow();
        echo view('login/editSeller',$data);
    }
    public function saveEdit($id){
        $input = $this->request->getVar();
        $result = $this->seller->where('id',$id)->update($input);
        echo json_encode($result);
    }
}
