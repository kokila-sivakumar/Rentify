<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BUYER/SELLER</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body,
        html {
            height: 100%;
            background-color: #f5f6f7;
        }

        .card23 {
            display: flex;
            flex-wrap: wrap;
            margin-top: 250px;
            justify-content: center;
        }

        .wrimagecard {
            margin-top: 0;
            margin-bottom: 1.5rem;
            text-align: left;
            position: relative;
            background: #fff;
            box-shadow: 12px 15px 20px 0px rgba(46, 61, 73, 0.15);
            border-radius: 4px;
            transition: all 0.3s ease;
            margin-left: 10px;
            margin-right: 100px;
            width: 140px;
        }

        .wrimagecard-topimage a {
            border-bottom: none;
            text-decoration: none;
            color: #525c65;
            transition: color 0.3s ease;
        }

        .wrimagecard-topimage a {
            width: 100%;
            height: 100%;
            display: block;
        }

        .wrimagecard-topimage_header {
            padding: 14px;
        }

        .wrimagecard-topimage_title {
            padding: 0;
            height: 30px;
            padding-bottom: 0;
            position: relative;
            text-align: center;
        }

        .ab_ab {
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <div class="container-fluid h-100 login">
        <div class="card23">
            <div class="wrimagecard wrimagecard-topimage">
                <a href="<?= base_url() ?>/buyer">
                    <div class="wrimagecard-topimage_header" style="background-color:#DFF0FA ">
                        <center><i class="fa-solid fa-user"style="color:#BB7824;font-size: 30px;" aria-hidden="true"></i></center>
                    </div>
                    <div class="wrimagecard-topimage_title">
                        <h4 class="ab_ab">BUYER
                        </h4>
                    </div>
                </a>
            </div>
            <div class="wrimagecard wrimagecard-topimage">
                <a href="<?= base_url() ?>/seller">
                    <div class="wrimagecard-topimage_header" style="background-color:  rgba(213, 15, 37, 0.1)">
                        <center><i class="fa-solid fa-hand-holding-dollar" style="color:#d50f25;font-size: 30px;" aria-hidden="true"></i></center>
                    </div>
                    <div class="wrimagecard-topimage_title">
                        <h4 class="ab_ab">SELLER
                        </h4>
                    </div>
                </a>
            </div>
        </div>
    </div>
</body>

</html>