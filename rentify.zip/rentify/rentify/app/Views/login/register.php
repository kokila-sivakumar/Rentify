<!DOCTYPE html>
<html lang="en">




<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google-signin-client_id" content="876556414701-dv5fqi6akeu8888dqoq846aku4i8v6ts.apps.googleusercontent.com">
    <title>Register Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/css/login.css">
    <link href="<?= base_url() ?>/assets/css/formValidation.min.css" rel="stylesheet" type="text/css">
    <link href="<?= base_url() ?>/assets/css/toastr.min.css" rel="stylesheet" type="text/css">
    <script src="<?= base_url() ?>/assets/js/jquery-3.3.1.js"></script>
    <script src="<?= base_url() ?>/assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url() ?>/assets/js/formValidation.min.js"></script>
    <script src="<?= base_url() ?>/assets/js/bootstrap_validation.min.js"></script>
    <script src="<?= base_url() ?>/assets/js/toastr.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet" type="text/css">
    <script src="https://apis.google.com/js/platform.js" async defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<style>
    .help-block {
        margin-bottom: 12px;
        text-align: left;
        color: red;
        display: block;
    }

    body,
    html {
        height: 100%;
        background-color: #f5f6f7;
    }

    .logo {
        width: 75px;
        height: 75px;
        object-fit: cover;
        margin: 0;
    }

    .logo-div {
        width: 120px;
        height: 120px;
        background-color: white;
        border-radius: 50%;
        position: absolute;
        top: -75px;
        left: calc(50% - 60px);
        box-shadow: rgba(0, 0, 0, 0.5) 2px 5px 20px -5px;
    }

    div.login-form {
        text-align: center;
        padding: 70px 25px 80px;
        max-width: 420px;
        width: 80%;
        position: relative;
        box-shadow: 3px 3px 6px #bfc3cf, -3px -3px 6px #fff;
        background-color: #CCFFDA;
        border-radius: 5px
    }

    .left-div {
        display: flex;
    }

    .login p,
    a {
        margin: 20px auto;
        text-decoration: none;
    }

    .email,
    .bttn-primary {
        position: relative;
        width: 100%;
        margin-bottom: 20px;
        height: 45px;
    }

    .bttn-primary {
        width: 98%;
        color: white !important;
        border-radius: 7px;
        border: none;
        background: #5BBD86;
        box-shadow: inset 3px 3px 7px rgba(0, 0, 0, 0.05), -3px -3px 7px white,
            3px 3px 7px rgba(0, 0, 0, 0.05), -3px -3px 7px white;
        font-weight: bold;
        opacity: 1;
        transition: 0.3s;
    }

    .bttn-primary:hover {
        opacity: 0.6;
        background: #5BBD86 !important;
    }

    .email label {
        position: absolute;
        top: 14px;
        left: 14px;
        background: none !important;




        padding: 0 5px;
        font-size: 15px;
        color: #999;
        transition: top 0.3s, font-size 0.3s;
    }

    .email input {
        margin: 3px auto;
        height: 45px;
        width: 98%;
        padding: 10px;
        border: 0px solid #999;
        border-radius: 7px;
        font-size: 16px;
        transition: border-color 0.3s;
        overflow: hidden;
    }

    .email input:focus {
        outline: none;
    }

    .email input:focus+label,
    .email input:not(:placeholder-shown)+label,
    .pass input:not(:placeholder-shown)+label {
        top: -10px;
        font-size: 15px;
        color: #2196f3;
        background-color: white;
    }




    .social-icons img {
        padding: 4px;
    }

    #checkbox-input {
        background: linear-gradient(145deg, #f5f6f7, #f5f6f7);
        width: 20px;
    }

    @media screen and (max-width: 767px) {
        .right-div {
            display: none;
        }

        div.login-form {
            padding: 80px 17px 80px;
            max-width: 450px;
        }
    }

    div.login-form {
        width: 90%;
    }

    .social-icons {
        padding: 0 7.4px;
    }




    .social-icons img {
        height: 45px;
        margin: 5px;
        background: linear-gradient(145deg, #f5f6f7, #f5f6f7);
        box-shadow: inset 3px 3px 7px rgba(0, 0, 0, 0.05), -3px -3px 7px white,
            3px 3px 7px rgba(0, 0, 0, 0.05), -3px -3px 7px white;
        border-radius: 100vw;
    }

    .connect {
        display: flex;
        width: 100%;
        align-items: center;
    }

    .connect hr {
        color: inherit;
        width: 25%;
        margin: auto;
        border: 0;
        border-top: 1px solid;
        opacity: 0.25;
        position: relative !important;
        /* top: -7px; */
    }

    .connect p {
        overflow: hidden;
        position: relative;
        background: none !important;
        /* background-color: white; */
        z-index: 2;
        width: 50%;
        margin: 16px 0px;
    }

    /*  Progress chart */




    .chart {
        --size: 120px;
        --value: 0%;
        --bord: 4px;
        --color: #a096fb;
        opacity: 0.6;
        transition: 0.3s;
        width: var(--size);
        height: var(--size);
        border: var(--bord) solid transparent;
        border-radius: 50%;
        background: linear-gradient(white, white) padding-box,
            conic-gradient(var(--color) var(--value), lightgrey var(--value)) border-box;
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 2em;
        box-sizing: border-box;
        /* flex */
        display: flex;
        justify-content: center;
        align-items: center;
        /* background: linear-gradient(145deg, #f5f6f7, #f5f6f7); */
        box-shadow: inset 3px 3px 7px rgba(0, 0, 0, 0.05), -3px -3px 7px white,
            3px 3px 7px rgba(0, 0, 0, 0.05), -3px -3px 7px white;
    }




    .chart-percentage p {
        margin: 0;
        font-size: 23px;
        color: #00c1d2;
        font-weight: 600;
    }

    .toggle-form {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        /* background-color: red; */
        display: flex;
        justify-content: space-between;
        padding: 0 24px;
    }

    .toggle-form>a {
        outline: 0;
        width: 45%;
        padding: 6px 12px;
        border-radius: 9px;
        font-weight: bold;
    }




    .toggle-form .login,
    .toggle-form .register {
        background: #65D496;
        box-shadow: inset 3px 3px 7px rgba(0, 0, 0, 0.05), -3px -3px 7px white,
            3px 3px 7px rgba(0, 0, 0, 0.05), -3px -3px 7px white;
        color: white;
        opacity: 0.6;
        transition: 0.3s;
    }

    .toggle-form .register:hover {
        opacity: .8;
    }

    .input-group-text {
        font-size: 14px;
        border-top-right-radius: 0px;
        border-bottom-right-radius: 0px;
        margin: 3px 0px;
        /* border: 1px solid #c5bebe !important; */
        border-right: none !important;
        background: linear-gradient(145deg, #f5f6f7, #f5f6f7);
        box-shadow: inset 3px 3px 7px rgba(0, 0, 0, 0.05), 0px 0px 0px white,
            3px 3px 7px rgba(0, 0, 0, 0.05), -3px -3px 7px white;
    }

    .input {
        border-top-left-radius: 0px !important;
        border-bottom-left-radius: 0px !important;
        padding-left: 33px;
        border: 1px solid #c5bebe !important;
        border-left: none !important;
        background: linear-gradient(145deg, #f5f6f7, #f5f6f7);
        box-shadow: inset 3px 3px 7px rgba(0, 0, 0, 0.05), 0px -3px 7px white,
            3px 3px 7px rgba(0, 0, 0, 0.05), 0px 0px 0px white;
    }

    .checkbox {
        text-align: left;
        margin-bottom: 20px;
    }

    .pass {
        margin-top: 25px !important;
    }

    .bxchck {
        margin-top: 25px !important;
    }

    .loginbs_bttn {
        color: #475996 !important
    }
</style>

<body>
    <div class="container-fluid h-100 login">
        <div class="row h-100">
            <div class="col-md-6 p-0 left-div ">
                <div class="login-form">
                    <div class="logo-div">
                        <div id="chart" class="chart">
                            <div class="chart-percentage">
                                <img class="logo login_logo" src="<?= base_url() ?>/assets/img/login.logo.png" alt="">
                            </div>
                        </div>
                    </div>
                    <form id="formData">
                        <div class="form-group email">
                            <div class="d-flex">
                                <span class="input-group-text"><i class="fa-solid fa-user"></i></span>
                                <input id="outlined-input" class="input" type="text" placeholder="First Name" value="" name="f_name" onkeyup="handleDelayForEmail(f_name)" autocomplete="off">
                                <!-- <label class="mail2" for="outlined-input">Email</label> -->
                            </div>
                        </div>
                        <div class="form-group email">
                            <div class="d-flex">
                                <span class="input-group-text"><i class="fa-solid fa-user"></i></span>
                                <input id="outlined-input" class="input" type="text" placeholder="Last Name" value="" name="l_name" onkeyup="handleDelayForEmail(l_name)" autocomplete="off">
                                <!-- <label class="mail2" for="outlined-input">Email</label> -->
                            </div>
                        </div>
                        <div class="form-group email">
                            <div class="d-flex">
                                <span class="input-group-text"><i class="fa-solid fa-phone"></i></span>
                                <input id="outlined-input" class="input" type="text" placeholder="Phone Number" value="" name="mobile" onkeyup="handleDelayForEmail(mobile)" autocomplete="off">
                                <!-- <label class="mail2" for="outlined-input">Email</label> -->
                            </div>
                        </div>
                        <div class="form-group email">
                            <div class="d-flex">
                                <span class="input-group-text"><i class="fa fa-envelope "></i></span>
                                <input id="outlined-input" class="input" type="email" placeholder="Email" value="" name="email" onkeyup="handleDelayForEmail(email)" autocomplete="off">
                                <!-- <label class="mail2" for="outlined-input">Email</label> -->
                            </div>
                        </div>




                        <div class="form-group email pass">
                            <div class="d-flex">
                                <span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
                                <input id="password-input" class="input" type="password" placeholder="Password" value="" name="password" onkeyup="handleDelayForPassword(password)" autocomplete="off">
                                <!-- <label class="mail2" for="password-input">Password</label> -->
                            </div>
                        </div>
                        <div class="checkbox bxchck">
                            <input type="checkbox" name="checkbox-input" id="checkbox-input">
                            <label for="checkbox">Remember me</label>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn bttn-primary login_mg login_bttn">Sign up</button>
                        </div>
                        <div class="social-icons">

                            <div class="connect form-group">

                            </div>
                            <p style="margin-bottom: 0;">Don't have an account?<a class="link-primary link_bttn" style="margin-left: 7px;" href="<?= base_url() ?>/register">Sign Up</a></p>
                            <p style="margin-bottom: 0;"><a class="link-primary link_bttn" href="<?= base_url() ?>/reset">Reset password?</a></p>
                        </div>
                    </form>
                    <div class="toggle-form">
                        <a href="" style="pointer-events: none; opacity: .5; border: 2px solid gray;" class="loginbs_bttn">Sign up</a>
                        <a class="register siglog" href="<?= base_url() ?>">Login</a>
                    </div>
                </div>
            </div>
            <div class="col-md-5 p-0 right-div" loading="lazy">
                <div class="d-flex align-items-center h-100 image-center">
                    <img src="<?= base_url() ?>/assets/img/house.png" class="w-75 rounded login-img-size" />
                </div>
            </div>
        </div>
    </div>




    <script>
        $(document).ready(function() {
            $('#formData').formValidation({
                    framework: 'bootstrap',
                    fields: {
                        email: {
                            validators: {
                                notEmpty: {
                                    message: 'Email is required'
                                }
                            }
                        },
                        password: {
                            validators: {
                                notEmpty: {
                                    message: 'Enter Password'
                                }
                            }
                        },
                    }
                })
                .on('success.form.fv', function(e) {
                    e.preventDefault();
                    var form = document.querySelector('#formData');
                    var formData = new FormData(form);
                    $.ajax({
                        type: 'POST',
                        url: '<?= base_url() ?>/loginController/check_user',
                        data: formData,
                        cache: false,
                        contentType: false,
                        processData: false,
                        dataType: 'json',
                        success: function(result) {
                            if (result == 100) {
                                toastr.success('Registered successfully!', 'Success');
                                setTimeout(() => {
                                    location.href = '<?= site_url() ?>';
                                }, 1500);
                            } {
                                toastr.warning('EmailId Already Exists', 'Invalid Credentials!');
                            }

                        }
                    });
                });
        });
    </script>
    <script>
        function onSignIn(googleUser) {
            var profile = googleUser.getBasicProfile();
            console.log('ID: ' + profile.getId());
            console.log('Name: ' + profile.getName());
            console.log('Image URL: ' + profile.getImageUrl());
            console.log('Email: ' + profile.getEmail());
        }
    </script>
    <script>
        let delay;

        function handleDelayForEmail(e) {
            clearTimeout(delay)
            delay = setTimeout(() => {
                tick(e);
                // console.log('hi');
            }, 1500)
        }

        function handleDelayForPassword(e) {
            clearTimeout(delay)
            delay = setTimeout(() => {
                tick(e);
                // console.log('hi');
            }, 1500)
        }
    </script>
    <script>
        const email = document.getElementById('outlined-input')
        const password = document.getElementById('password-input')
        let chart = document.querySelector('#chart');
        let pc = 0; // percent completed
        let count = 0;

        function tick(e) {
            if (e.value !== "") {
                if (pc < 100) {
                    pc = pc + 50;
                    setInterval(() => {
                        if (count <= pc) {




                            chart.style.setProperty('--value', count + '%');
                            console.log(pc, count);
                            count += 2;
                            // pc++;
                        }
                    }, 100)




                }
            }
            if (pc > 0 && e.value == "") {




                pc = pc - 50;




                let interval = setInterval(() => {
                    if (count >= pc) {




                        chart.style.setProperty('--value', count + '%');
                        console.log(pc, count);
                        count--;




                        if (count == 0 || count == pc) {
                            clearInterval(interval);
                        }
                        // pc++;
                    }
                }, 1)




            }








            // chart.querySelector('p').innerHTML = pc + '%';
        }
    </script>
</body>

</html>