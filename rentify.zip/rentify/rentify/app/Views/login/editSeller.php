<form id="data_forms">
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" class="form-control" name="name" id="name" value="<?= $edit->name ?>">
    </div>
    <div class="form-group">
        <label for="mobile_number">Mobile Number</label>
        <input type="text" class="form-control" name="mobile_number" id="mobile_number" value="<?= $edit->mobile_number ?>">
    </div>
    <div class="form-group">
        <label for="age">Place</label>
        <input type="text" class="form-control" name="place" id="age" value="<?= $edit->place ?>">
    </div>
    <div class="form-group">
        <label for="bed">Number of Bedrooms & Bathrooms</label>
        <input type="text" class="form-control" name="bed" id="bed" value="<?= $edit->bed ?>">
    </div>
    <div class="form-group">
        <label for="hospital">Hospitals & colleges Nearby</label>
        <input type="text" class="form-control" name="hospital" id="hospital" value="<?= $edit->hospital ?>">
    </div>
    <div class="text-right">
        <button class="btn btn-success" type="submit">Save</button>
    </div>
</form>
<script>
    $(document).ready(function() {
        $('#data_forms').formValidation({
                framework: 'bootstrap',
                fields: {
                    name: {
                        validators: {
                            notEmpty: {
                                message: 'Name is required '
                            },
                        }
                    },
                    mobile_number: {
                        validators: {
                            notEmpty: {
                                message: 'Mobile Number is required'
                            },
                            stringLength: {
                                max: 10,
                                min: 10,
                                message: 'max 10 and min 10'
                            }
                        }
                    }
                }
            })
            .on('success.form.fv', function(e) {
                e.preventDefault();
                var form = document.querySelector('#data_forms');
                var dataForm = new FormData(form);
                $.ajax({
                    type: 'POST',
                    url: '<?= base_url() ?>/loginController/saveEdit/<?= $edit->id ?>',
                    data: dataForm,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(result) {
                        toastr.success('Update successfully', 'Success');
                        $('#modal_md').modal('hide');
                        getUsers();
                    }
                });
            });
    });
</script>