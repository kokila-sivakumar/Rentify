<html>

<head>
    <title>Seller</title>
    <link rel="stylesheet" href="<?= base_url() ?>/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/css/font.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/css/toastr.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/css/select2.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/css/formValidation.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/css/bootstrap-datepicker.standalone.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/solid.min.css" integrity="sha512-pZlKGs7nEqF4zoG0egeK167l6yovsuL8ap30d07kA5AJUq+WysFlQ02DLXAmN3n0+H3JVz5ni8SJZnrOaYXWBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<style>
    .help-block {
        color: red !important;
    }

    * {
        padding: 0px;
        margin: 0px;
        box-sizing: border-box;
    }

    .container-fluid {
        height: 100vh;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        margin: 0px !important;
    }

    small {
        color: red;
    }

    h2 {
        font-weight: 900 !important;
    }

    .card {
        width: 350px;
        margin: auto !important;
        align-items: center;
    }

    #input {
        border: none !important;
        border-bottom: 2px solid #4987c6 !important;
    }

    #input:focus {
        box-shadow: none !important;
    }
</style>

<body>

    <div class="d-flex justify-content-center align-items-center">
        <div class="card">
            <div class="card-body">
                <form id="data_form">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" name="name" id="name">
                    </div>
                    <div class="form-group">
                        <label for="mobile_number">Mobile Number</label>
                        <input type="text" class="form-control" name="mobile_number" id="mobile_number">
                    </div>
                    <div class="form-group">
                        <label for="place">Place</label>
                        <input type="text" class="form-control" name="place" id="place">
                    </div>
                    <div class="form-group">
                        <label for="bed">Number of Bedrooms & Bathrooms</label>
                        <input type="text" class="form-control" name="bed" id="bed">
                    </div>
                    <div class="form-group">
                        <label for="hospital">Hospitals & colleges Nearby</label>
                        <input type="text" class="form-control" name="hospital" id="hospital">
                    </div>
                    <div class="text-right">
                        <button class="btn btn-success" type="submit">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <table class="table" style="margin-top: 50px;background-color:white;">
        <thead>
            <th>S.No</th>
            <th>Name</th>
            <th>Mobile Number</th>
            <th>place</th>
            <th>Bedrooms & Bathrooms</th>
            <th>Hospitals & colleges</th>
            <th>Action</th>
        </thead>
        <tbody id="append"></tbody>
    </table>
    <div class="modal fade" id="modal_md">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="btn-close modal_dis" data-dismiss="modal" aria-label="Close">X</button>
                </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_md">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="btn-close modal_dis" data-dismiss="modal" aria-label="Close">X</button>
                </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>
</body>
<script src="<?= base_url() ?>/assets/js/jquery.min.js"></script>
<script src="<?= base_url() ?>/assets/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>/assets/js/dataTables.bootstrap4.min.js"></script>
<script src="<?= base_url() ?>/assets/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url() ?>/assets/js/toastr.min.js"></script>
<script src="<?= base_url() ?>/assets/js/formValidation.min.js"></script>
<script src="<?= base_url() ?>/assets/js/bootstrap_validation.min.js"></script>
<script src="<?= base_url() ?>/assets/js/bootstrap-datepicker.min.js"></script>
<script src="<?= base_url() ?>/assets/js/select2.min.js"></script>
<script src="<?= base_url() ?>/assets/js/script.js"></script>
<script>
    function showMdModal(url, title) {
        jQuery('#modal_md .modal-body').html('<div style="text-align:center;"><img src="<?= base_url() ?>/assets/images/preloader.gif" /></div>');
        jQuery('#modal_md').appendTo("body").modal('show', {
            backdrop: 'true'
        });
        $.ajax({
            url: url,
            success: function(response) {
                jQuery('#modal_md .modal-title').html(title);
                jQuery('#modal_md .modal-body').html(response);
            }
        });
    }
</script>
<script>
    $(document).ready(function() {
        $('#data_form').formValidation({
                framework: 'bootstrap',
                fields: {
                    name: {
                        validators: {
                            notEmpty: {
                                message: 'Email is required'
                            }
                        }
                    },
                    mobile: {
                        validators: {
                            notEmpty: {
                                message: 'Enter Password'
                            }
                        }
                    },
                }
            })
            .on('success.form.fv', function(e) {
                e.preventDefault();
                var form = document.querySelector('#data_form');
                var formData = new FormData(form);
                $.ajax({
                    type: 'POST',
                    url: '<?= base_url() ?>/saveplace',
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(result) {
                        if (result == 100) {
                            toastr.success('Registered successfully!', 'Success');
                            setTimeout(() => {
                                location.href = '<?= site_url() ?>';
                            }, 1500);
                        } {
                            toastr.warning('EmailId Already Exists', 'Invalid Credentials!');
                        }

                    }
                });
            });
    });
</script>
<script>
    function getUsers() {
        $.ajax({
            type: 'POST',
            url: '<?= base_url() ?>/getSeller',
            dataType: 'json',
            success: function(table) {
                console.log(table);
                $('#append').html(table);
            }
        });
    }
    getUsers();
</script>

</html>